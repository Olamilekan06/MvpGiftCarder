# MvpGiftCarder

A responsive, static GitHub Pages MVP/demo for a Nigerian gift-card trade-request concept. It uses plain HTML, CSS, and vanilla JavaScript. No server, build step, package manager, or paid library is required.

## Files

Upload these four files to the **root** of your GitHub repository:

- `index.html` — page structure and form
- `styles.css` — responsive design
- `app.js` — placeholder rates, calculator, local demo submissions, receipt download, and local reference lookup
- `README.md` — this guide

## Publish with GitHub Pages

1. Create a repository on GitHub.
2. Upload `index.html`, `styles.css`, `app.js`, and `README.md` to the repository root.
3. Commit the files to the `main` branch.
4. Open the repository's **Settings**.
5. Select **Pages** in the sidebar.
6. Under **Build and deployment**, choose **Deploy from a branch**.
7. Select branch **main**.
8. Select folder **/ (root)** (GitHub may display this as `/root` in some instructions).
9. Click **Save**.
10. Wait for deployment, then open the GitHub Pages URL shown on the Pages settings screen. For a project repository it is commonly `https://YOUR-USERNAME.github.io/YOUR-REPOSITORY/`.

If the page is missing CSS or JavaScript, confirm that all four files are in the repository root and that the names match exactly, including letter case.

## Change the demo rates

Open `app.js` and find the `RATES` object near the top. Each `rate` is an example NGN amount per 1 USD. Edit the numbers, commit the change, and GitHub Pages will redeploy.

Example:

```js
amazon: { name: 'Amazon', rate: 900, icon: '📦', tint: '#fff0d9' }
```

These are **DEMO / PLACEHOLDER rates only**, not current market quotes or guaranteed offers. The calculator and rate cards read from this one object.

## Important MVP limitations

- This is a **demo, not a production gift-card trading system**.
- The form stores submissions in the current browser's `localStorage` only. It does not send them to an operator, database, email, WhatsApp, or payout provider.
- Data in `localStorage` is not secure, is not shared between browsers/devices, and may be cleared by the user or browser. Do not submit real customer or financial information to this demo.
- The reference tracker only searches submissions saved in the same browser profile.
- A receipt only confirms a local demo save. It does not mean a trade was accepted, a card was checked, or a payout was made.
- Every submission stays **Pending Review**. There is no admin backend, automatic redemption, card-code checking, or automatic payout.
- The form does not ask for gift-card codes, passwords, OTPs, PINs, or banking login credentials.
- Do not put secret API keys in `index.html`, `styles.css`, or `app.js`.

## Before production

A real service needs a secure backend, server-side validation, access controls, data minimization and retention policies, an actual manual-review workflow, support/contact handling, and a verified payout process. Connect the browser UI to a protected API (for example, Supabase or Firebase with properly designed security rules) rather than exposing credentials or treating `localStorage` as a database. Review applicable Nigerian legal, privacy, consumer-protection, and financial obligations before accepting real trades.
