'use strict';

/*
 * MvpGiftCarder MVP demo
 * - Estimates use clearly labelled placeholder rates.
 * - Trade requests are stored in this browser only and remain Pending Review.
 * - Never collect gift-card codes, passwords, OTPs, PINs, or banking credentials.
 * FUTURE BACKEND: replace the localStorage save/read functions with calls to a
 * secure server-side API (for example, a protected Supabase/Firebase backend).
 * Never place secret API keys in this public GitHub Pages code.
 */

const RATES = {
  amazon: { name: 'Amazon', rate: 900, icon: '📦', tint: '#fff0d9' },
  apple: { name: 'Apple / iTunes', rate: 880, icon: '', tint: '#f0f1f4' },
  google: { name: 'Google Play', rate: 850, icon: '▶', tint: '#e7f4ff' },
  steam: { name: 'Steam', rate: 820, icon: '🎮', tint: '#e9efff' },
  razer: { name: 'Razer Gold', rate: 800, icon: '⚡', tint: '#e8f8e8' },
  other: { name: 'Other', rate: 700, icon: '🎁', tint: '#f4eaff' }
};

const STORAGE_KEY = 'mvpgiftcarder_demo_trades_v1';
const moneyFormatter = new Intl.NumberFormat('en-NG', {
  style: 'currency',
  currency: 'NGN',
  maximumFractionDigits: 2
});

let latestTradeForReceipt = null;

function formatNaira(amount) {
  if (!Number.isFinite(amount)) return '₦0';
  return moneyFormatter.format(amount).replace('NGN', '₦');
}

function getRate(cardKey) {
  return RATES[cardKey] ? RATES[cardKey].rate : RATES.other.rate;
}

function estimate(cardKey, value) {
  const numericValue = Number(value);
  if (!Number.isFinite(numericValue) || numericValue <= 0) return 0;
  return Math.round(numericValue * getRate(cardKey) * 100) / 100;
}

function populateGiftCardSelect(select, selectedKey = 'amazon') {
  select.innerHTML = '<option value="">Select gift card</option>';
  Object.entries(RATES).forEach(([key, card]) => {
    const option = document.createElement('option');
    option.value = key;
    option.textContent = card.name;
    if (key === selectedKey) option.selected = true;
    select.appendChild(option);
  });
}

function updateEstimate(cardSelect, valueInput, amountElement, rateElement) {
  const key = cardSelect.value || 'amazon';
  const value = Number(valueInput.value);
  const amount = estimate(key, value);
  amountElement.textContent = formatNaira(amount);
  rateElement.textContent = `Demo rate: ${formatNaira(getRate(key))} per $1`;
  return amount;
}

function renderRateCards() {
  const grid = document.getElementById('rateGrid');
  grid.replaceChildren();
  Object.entries(RATES).forEach(([key, card]) => {
    const article = document.createElement('article');
    article.className = 'rate-card';

    const top = document.createElement('div');
    top.className = 'rate-card-top';
    const icon = document.createElement('span');
    icon.className = 'gift-icon';
    icon.style.setProperty('--icon-bg', card.tint);
    icon.setAttribute('aria-hidden', 'true');
    icon.textContent = card.icon;
    const tag = document.createElement('span');
    tag.className = 'demo-tag';
    tag.textContent = 'DEMO RATE';
    top.append(icon, tag);

    const title = document.createElement('h3');
    title.textContent = card.name;
    const rate = document.createElement('div');
    rate.className = 'rate-value';
    rate.textContent = formatNaira(card.rate);
    const unit = document.createElement('span');
    unit.className = 'rate-unit';
    unit.textContent = ' per $1';

    article.append(top, title, rate, unit);
    article.setAttribute('aria-label', `${card.name}: demo rate ${formatNaira(card.rate)} per US dollar`);
    grid.appendChild(article);
  });
}

function readTrades() {
  try {
    const saved = localStorage.getItem(STORAGE_KEY);
    const trades = saved ? JSON.parse(saved) : [];
    return Array.isArray(trades) ? trades : [];
  } catch (error) {
    console.error('Could not read demo trades from localStorage.', error);
    return [];
  }
}

function saveTradeLocally(trade) {
  // DEMO ONLY: localStorage is not secure, shared, or a real submission service.
  // FUTURE BACKEND: POST this data to a secure API; validate on the server,
  // protect access to personal data, and configure lawful retention/deletion.
  const trades = readTrades();
  trades.push(trade);
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(trades));
    return true;
  } catch (error) {
    console.error('Could not save demo trade.', error);
    return false;
  }
}

function generateTradeId() {
  const date = new Date();
  const yyyy = date.getFullYear();
  const mm = String(date.getMonth() + 1).padStart(2, '0');
  const dd = String(date.getDate()).padStart(2, '0');
  const random = Math.floor(100000 + Math.random() * 900000);
  return `MVP-${yyyy}${mm}${dd}-${random}`;
}

function getFormTrade(form, tradeId, estimatedPayout) {
  const data = new FormData(form);
  return {
    id: tradeId,
    createdAt: new Date().toISOString(),
    giftCardKey: String(data.get('giftCard')),
    giftCard: RATES[String(data.get('giftCard'))]?.name || 'Other',
    country: String(data.get('cardCountry')),
    valueUsd: Number(data.get('cardValue')),
    cardFormat: String(data.get('cardFormat')),
    estimatedPayout,
    customerName: String(data.get('fullName')).trim(),
    phone: String(data.get('phone')).trim(),
    email: String(data.get('email') || '').trim(),
    bank: String(data.get('bank')),
    accountNumber: String(data.get('accountNumber')).trim(),
    accountName: String(data.get('accountName')).trim(),
    note: String(data.get('note') || '').trim(),
    status: 'Pending Review'
  };
}

function receiptText(trade) {
  return [
    'MvpGiftCarder — Demo Trade Receipt',
    '==================================',
    `Trade ID: ${trade.id}`,
    `Date: ${new Date(trade.createdAt).toLocaleString('en-NG')}`,
    `Gift-card type: ${trade.giftCard}`,
    `Country: ${trade.country}`,
    `Card format: ${trade.cardFormat}`,
    `Value: $${Number(trade.valueUsd).toFixed(2)} USD`,
    `Estimated payout: ${formatNaira(Number(trade.estimatedPayout))}`,
    `Customer name: ${trade.customerName}`,
    `Phone: ${trade.phone}`,
    `Bank: ${trade.bank}`,
    `Account number: ${trade.accountNumber}`,
    `Account name: ${trade.accountName}`,
    `Status: ${trade.status}`,
    '',
    'DEMO ONLY: This receipt confirms a local browser save only.',
    'No trade has been sent, verified, approved, or paid.',
    'The estimate is not a guaranteed rate or payout.'
  ].join('\n');
}

function downloadReceipt(trade) {
  if (!trade) return;
  const blob = new Blob([receiptText(trade)], { type: 'text/plain;charset=utf-8' });
  const url = URL.createObjectURL(blob);
  const anchor = document.createElement('a');
  anchor.href = url;
  anchor.download = `${trade.id}-receipt.txt`;
  document.body.appendChild(anchor);
  anchor.click();
  anchor.remove();
  URL.revokeObjectURL(url);
}

function showError(message) {
  const error = document.getElementById('formError');
  error.textContent = message;
  error.hidden = false;
}

function hideError() {
  const error = document.getElementById('formError');
  error.textContent = '';
  error.hidden = true;
}

function initNavigation() {
  const toggle = document.getElementById('menuToggle');
  const links = document.getElementById('navLinks');
  toggle.addEventListener('click', () => {
    const isOpen = links.classList.toggle('is-open');
    toggle.setAttribute('aria-expanded', String(isOpen));
  });
  links.querySelectorAll('a').forEach(link => {
    link.addEventListener('click', () => {
      links.classList.remove('is-open');
      toggle.setAttribute('aria-expanded', 'false');
    });
  });
}

function initCalculator() {
  const quickGiftCard = document.getElementById('quickGiftCard');
  const quickValue = document.getElementById('quickValue');
  const quickAmount = document.getElementById('quickEstimateAmount');
  const quickRate = document.getElementById('quickRateLabel');
  const giftCard = document.getElementById('giftCard');
  const cardValue = document.getElementById('cardValue');
  const formAmount = document.getElementById('formEstimateAmount');
  const formRate = document.getElementById('formRateLabel');

  populateGiftCardSelect(quickGiftCard, 'amazon');
  populateGiftCardSelect(giftCard, 'amazon');

  const updateQuick = () => updateEstimate(quickGiftCard, quickValue, quickAmount, quickRate);
  const updateForm = () => updateEstimate(giftCard, cardValue, formAmount, formRate);
  quickGiftCard.addEventListener('change', () => {
    updateQuick();
    giftCard.value = quickGiftCard.value;
    updateForm();
  });
  quickValue.addEventListener('input', updateQuick);
  giftCard.addEventListener('change', () => {
    updateForm();
    quickGiftCard.value = giftCard.value;
    updateQuick();
  });
  cardValue.addEventListener('input', () => {
    updateForm();
    quickValue.value = cardValue.value;
    updateQuick();
  });
  updateQuick();
  updateForm();
}

function initTradeForm() {
  const form = document.getElementById('tradeForm');
  const successPanel = document.getElementById('successPanel');

  form.addEventListener('submit', event => {
    event.preventDefault();
    hideError();

    const accountNumber = document.getElementById('accountNumber');
    accountNumber.setCustomValidity(/^\d{10}$/.test(accountNumber.value.trim())
      ? ''
      : 'Enter exactly 10 digits for the Nigerian account number.');

    if (!form.reportValidity()) return;

    const giftCard = document.getElementById('giftCard');
    const cardValue = document.getElementById('cardValue');
    const payout = estimate(giftCard.value, cardValue.value);
    const trade = getFormTrade(form, generateTradeId(), payout);

    if (!saveTradeLocally(trade)) {
      showError('This browser could not save the demo request. Check browser storage settings and try again. No request was sent.');
      return;
    }

    latestTradeForReceipt = trade;
    document.getElementById('successTradeId').textContent = trade.id;
    successPanel.hidden = false;
    successPanel.focus();
    successPanel.scrollIntoView({ behavior: 'smooth', block: 'start' });
    document.getElementById('trackId').value = trade.id;
    document.getElementById('trackResult').hidden = true;
  });

  document.getElementById('downloadReceipt').addEventListener('click', () => downloadReceipt(latestTradeForReceipt));
  document.getElementById('anotherTrade').addEventListener('click', () => {
    form.reset();
    document.getElementById('giftCard').value = 'amazon';
    document.getElementById('cardValue').value = '100';
    document.getElementById('quickGiftCard').value = 'amazon';
    document.getElementById('quickValue').value = '100';
    document.getElementById('successPanel').hidden = true;
    hideError();
    document.getElementById('start-trade').scrollIntoView({ behavior: 'smooth', block: 'start' });
    document.getElementById('giftCard').dispatchEvent(new Event('change'));
  });
}

function initTracking() {
  const form = document.getElementById('trackForm');
  const input = document.getElementById('trackId');
  const result = document.getElementById('trackResult');

  form.addEventListener('submit', event => {
    event.preventDefault();
    const id = input.value.trim().toUpperCase();
    const trade = readTrades().find(item => item.id.toUpperCase() === id);
    result.hidden = false;
    if (!trade) {
      result.textContent = 'No matching demo reference was found in this browser. This tracker cannot search other devices or a server.';
      return;
    }
    result.textContent = `Trade ${trade.id} — Status: ${trade.status}. Saved locally on ${new Date(trade.createdAt).toLocaleString('en-NG')}. This is not a live trading-system update.`;
  });
}

document.addEventListener('DOMContentLoaded', () => {
  renderRateCards();
  initNavigation();
  initCalculator();
  initTradeForm();
  initTracking();
});
